from django.contrib import admin

from .models import ObjectViewed
# Register your models here.

admin.site.register(ObjectViewed)
